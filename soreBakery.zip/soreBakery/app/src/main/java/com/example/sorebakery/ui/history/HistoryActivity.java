package com.example.sorebakery.ui.history;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sorebakery.R;
import com.example.sorebakery.adapter.HistoryAdapter;
import com.example.sorebakery.data.dao.TransactionDao;
import com.example.sorebakery.data.model.Transaction;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerViewHistory;
    private HistoryAdapter historyAdapter;
    private List<Transaction> transactionList = new ArrayList<>();
    private TransactionDao transactionDao;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        transactionDao = new TransactionDao(this);

        recyclerViewHistory = findViewById(R.id.recycler_view_history);
        recyclerViewHistory.setLayoutManager(new LinearLayoutManager(this));

        historyAdapter = new HistoryAdapter(transactionList, transaction -> {
            Intent intent = new Intent(HistoryActivity.this, HistoryDetailActivity.class);
            intent.putExtra("TRANSACTION_ID", transaction.getId());
            startActivity(intent);
        });
        recyclerViewHistory.setAdapter(historyAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHistory();
    }

    private void loadHistory() {
        transactionDao.open();
        transactionList.clear();
        transactionList.addAll(transactionDao.getAllTransactions());
        historyAdapter.setTransactions(transactionList);
        transactionDao.close();
    }
}
