package com.example.sorebakery.ui.product;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.sorebakery.R;
import com.example.sorebakery.data.dao.ProductDao;
import com.example.sorebakery.data.model.Product;
import com.example.sorebakery.util.ImageUtil;

import java.io.File;

public class AddEditProductActivity extends AppCompatActivity {

    private EditText editTextName, editTextPrice, editTextStock;
    private Button buttonSave, buttonSelectImage;
    private ImageView imageViewPreview;
    private ProductDao productDao;
    private Product currentProduct;
    private boolean isEditMode = false;
    private Uri selectedImageUri; // URI dari galeri (sementara)

    // Launcher untuk memilih gambar dari galeri
    private final ActivityResultLauncher<Intent> imagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    selectedImageUri = result.getData().getData();
                    
                    // Tampilkan pratinjau menggunakan Glide
                    Glide.with(this)
                            .load(selectedImageUri)
                            .centerCrop()
                            .into(imageViewPreview);
                }
            }
    );

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_product);

        editTextName = findViewById(R.id.edit_text_product_name);
        editTextPrice = findViewById(R.id.edit_text_product_price);
        editTextStock = findViewById(R.id.edit_text_product_stock);
        buttonSave = findViewById(R.id.button_save_product);
        buttonSelectImage = findViewById(R.id.button_select_image);
        imageViewPreview = findViewById(R.id.image_view_product_preview);

        productDao = new ProductDao(this);

        long productId = getIntent().getLongExtra("PRODUCT_ID", -1);

        if (productId != -1) {
            isEditMode = true;
            productDao.open();
            // Inefficient way, a getById would be better.
            for(Product p : productDao.getAllProducts()){
                if(p.getId() == productId){
                    currentProduct = p;
                    break;
                }
            }
            productDao.close();

            if (currentProduct != null) {
                editTextName.setText(currentProduct.getName());
                editTextPrice.setText(String.valueOf(currentProduct.getPrice()));
                editTextStock.setText(String.valueOf(currentProduct.getStock()));
                
                // Load gambar yang sudah ada
                if (currentProduct.getImagePath() != null && !currentProduct.getImagePath().isEmpty()) {
                    Glide.with(this)
                            .load(new File(currentProduct.getImagePath())) // Load dari file path
                            .centerCrop()
                            .placeholder(R.drawable.ic_launcher_background)
                            .into(imageViewPreview);
                }
            }
        }

        buttonSelectImage.setOnClickListener(v -> openGallery());
        buttonSave.setOnClickListener(v -> saveProduct());
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        imagePickerLauncher.launch(intent);
    }

    private void saveProduct() {
        String name = editTextName.getText().toString().trim();
        String priceStr = editTextPrice.getText().toString().trim();
        String stockStr = editTextStock.getText().toString().trim();

        if (name.isEmpty() || priceStr.isEmpty() || stockStr.isEmpty()) {
            Toast.makeText(this, "Harap isi semua kolom", Toast.LENGTH_SHORT).show();
            return;
        }

        int price = Integer.parseInt(priceStr);
        int stock = Integer.parseInt(stockStr);
        
        // Logika Penyimpanan Gambar Baru
        String finalImagePath = null;
        
        if (selectedImageUri != null) {
            // Jika user memilih gambar baru, simpan ke internal storage
            finalImagePath = ImageUtil.saveImageToInternalStorage(this, selectedImageUri);
            
            // Hapus gambar lama jika ada (opsional, untuk menghemat ruang)
            if (isEditMode && currentProduct.getImagePath() != null) {
                // ImageUtil.deleteImageFromInternalStorage(currentProduct.getImagePath());
            }
        } else if (isEditMode) {
            // Jika tidak memilih gambar baru, gunakan path lama
            finalImagePath = currentProduct.getImagePath();
        }

        productDao.open();
        if (isEditMode) {
            currentProduct.setName(name);
            currentProduct.setPrice(price);
            currentProduct.setStock(stock);
            currentProduct.setImagePath(finalImagePath);
            productDao.updateProduct(currentProduct);
        } else {
            productDao.addProduct(name, price, stock, finalImagePath);
        }
        productDao.close();

        setResult(RESULT_OK);
        finish();
    }
}
