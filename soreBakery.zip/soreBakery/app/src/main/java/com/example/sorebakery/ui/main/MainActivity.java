package com.example.sorebakery.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sorebakery.R;
import com.example.sorebakery.ui.history.HistoryActivity;
import com.example.sorebakery.ui.pos.PosActivity;
import com.example.sorebakery.ui.product.ProductActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonManageProducts = findViewById(R.id.button_manage_products);
        Button buttonPos = findViewById(R.id.button_pos);
        Button buttonTransactionHistory = findViewById(R.id.button_transaction_history);

        buttonManageProducts.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProductActivity.class);
            startActivity(intent);
        });

        buttonPos.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PosActivity.class);
            startActivity(intent);
        });

        buttonTransactionHistory.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
            startActivity(intent);
        });
    }
}
