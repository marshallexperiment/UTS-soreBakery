package com.example.sorebakery.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "sorebakery.db";
    private static final int DATABASE_VERSION = 2; // Versi dinaikkan

    // Tabel Products
    public static final String TABLE_PRODUCTS = "products";
    public static final String COLUMN_PRODUCT_ID = "id";
    public static final String COLUMN_PRODUCT_NAME = "name";
    public static final String COLUMN_PRODUCT_PRICE = "price";
    public static final String COLUMN_PRODUCT_STOCK = "stock";
    public static final String COLUMN_PRODUCT_IMAGE_PATH = "image_path"; // Kolom baru

    // Tabel Transactions
    public static final String TABLE_TRANSACTIONS = "transactions";
    public static final String COLUMN_TRANSACTION_ID = "id";
    public static final String COLUMN_TRANSACTION_DATE = "transaction_date";
    public static final String COLUMN_TRANSACTION_TOTAL = "total_amount";

    // Tabel Transaction Items
    public static final String TABLE_TRANSACTION_ITEMS = "transaction_items";
    public static final String COLUMN_ITEM_ID = "id";
    public static final String COLUMN_ITEM_TRANSACTION_ID = "transaction_id";
    public static final String COLUMN_ITEM_PRODUCT_ID = "product_id";
    public static final String COLUMN_ITEM_QUANTITY = "quantity";
    public static final String COLUMN_ITEM_PRICE_AT_TRANSACTION = "price_at_transaction";

    // SQL statement untuk membuat tabel products (diperbarui)
    private static final String CREATE_TABLE_PRODUCTS = "CREATE TABLE " + TABLE_PRODUCTS + " (" +
            COLUMN_PRODUCT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_PRODUCT_NAME + " TEXT NOT NULL, " +
            COLUMN_PRODUCT_PRICE + " INTEGER NOT NULL, " +
            COLUMN_PRODUCT_STOCK + " INTEGER NOT NULL, " +
            COLUMN_PRODUCT_IMAGE_PATH + " TEXT);"; // Penambahan kolom baru

    // SQL statement lainnya (tetap sama)
    private static final String CREATE_TABLE_TRANSACTIONS = "CREATE TABLE " + TABLE_TRANSACTIONS + " (" +
            COLUMN_TRANSACTION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_TRANSACTION_DATE + " TEXT NOT NULL, " +
            COLUMN_TRANSACTION_TOTAL + " INTEGER NOT NULL);";

    private static final String CREATE_TABLE_TRANSACTION_ITEMS = "CREATE TABLE " + TABLE_TRANSACTION_ITEMS + " (" +
            COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_ITEM_TRANSACTION_ID + " INTEGER NOT NULL, " +
            COLUMN_ITEM_PRODUCT_ID + " INTEGER NOT NULL, " +
            COLUMN_ITEM_QUANTITY + " INTEGER NOT NULL, " +
            COLUMN_ITEM_PRICE_AT_TRANSACTION + " INTEGER NOT NULL, " +
            "FOREIGN KEY(" + COLUMN_ITEM_TRANSACTION_ID + ") REFERENCES " + TABLE_TRANSACTIONS + "(" + COLUMN_TRANSACTION_ID + "), " +
            "FOREIGN KEY(" + COLUMN_ITEM_PRODUCT_ID + ") REFERENCES " + TABLE_PRODUCTS + "(" + COLUMN_PRODUCT_ID + "));";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_PRODUCTS);
        db.execSQL(CREATE_TABLE_TRANSACTIONS);
        db.execSQL(CREATE_TABLE_TRANSACTION_ITEMS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Jika ada perubahan skema, drop tabel lama dan buat lagi.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSACTION_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSACTIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCTS);
        onCreate(db);
    }
}
