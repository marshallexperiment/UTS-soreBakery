package com.example.sorebakery.data.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.sorebakery.data.model.Product;
import com.example.sorebakery.database.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class ProductDao {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    private String[] allColumns = {
            DatabaseHelper.COLUMN_PRODUCT_ID,
            DatabaseHelper.COLUMN_PRODUCT_NAME,
            DatabaseHelper.COLUMN_PRODUCT_PRICE,
            DatabaseHelper.COLUMN_PRODUCT_STOCK,
            DatabaseHelper.COLUMN_PRODUCT_IMAGE_PATH // Kolom baru
    };

    public ProductDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public Product addProduct(String name, int price, int stock, String imagePath) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_PRODUCT_NAME, name);
        values.put(DatabaseHelper.COLUMN_PRODUCT_PRICE, price);
        values.put(DatabaseHelper.COLUMN_PRODUCT_STOCK, stock);
        values.put(DatabaseHelper.COLUMN_PRODUCT_IMAGE_PATH, imagePath); // Menyimpan path gambar

        long insertId = database.insert(DatabaseHelper.TABLE_PRODUCTS, null, values);

        Cursor cursor = database.query(DatabaseHelper.TABLE_PRODUCTS, allColumns, DatabaseHelper.COLUMN_PRODUCT_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Product newProduct = cursorToProduct(cursor);
        cursor.close();
        return newProduct;
    }

    public void updateProduct(Product product) {
        long id = product.getId();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_PRODUCT_NAME, product.getName());
        values.put(DatabaseHelper.COLUMN_PRODUCT_PRICE, product.getPrice());
        values.put(DatabaseHelper.COLUMN_PRODUCT_STOCK, product.getStock());
        values.put(DatabaseHelper.COLUMN_PRODUCT_IMAGE_PATH, product.getImagePath()); // Update path gambar

        database.update(DatabaseHelper.TABLE_PRODUCTS, values, DatabaseHelper.COLUMN_PRODUCT_ID + " = " + id, null);
    }

    public void deleteProduct(Product product) {
        long id = product.getId();
        database.delete(DatabaseHelper.TABLE_PRODUCTS, DatabaseHelper.COLUMN_PRODUCT_ID + " = " + id, null);
    }

    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();

        Cursor cursor = database.query(DatabaseHelper.TABLE_PRODUCTS, allColumns, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Product product = cursorToProduct(cursor);
            products.add(product);
            cursor.moveToNext();
        }
        cursor.close();
        return products;
    }

    private Product cursorToProduct(Cursor cursor) {
        Product product = new Product();
        product.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_ID)));
        product.setName(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_NAME)));
        product.setPrice(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_PRICE)));
        product.setStock(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_STOCK)));
        product.setImagePath(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_IMAGE_PATH))); // Baca path gambar
        return product;
    }
}
