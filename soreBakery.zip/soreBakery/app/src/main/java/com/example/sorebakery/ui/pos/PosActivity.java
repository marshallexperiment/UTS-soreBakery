package com.example.sorebakery.ui.pos;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sorebakery.R;
import com.example.sorebakery.adapter.CartAdapter;
import com.example.sorebakery.adapter.PosProductAdapter;
import com.example.sorebakery.data.dao.ProductDao;
import com.example.sorebakery.data.dao.TransactionDao;
import com.example.sorebakery.data.dao.TransactionDetailDao;
import com.example.sorebakery.data.model.Product;
import com.example.sorebakery.data.model.TransactionDetail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PosActivity extends AppCompatActivity {

    private ProductDao productDao;
    private TransactionDao transactionDao;
    private TransactionDetailDao transactionDetailDao;

    private RecyclerView rvProducts, rvCart;
    private PosProductAdapter productAdapter;
    private CartAdapter cartAdapter;
    private TextView tvTotalPrice;

    private List<Product> productList = new ArrayList<>();
    private List<TransactionDetail> cartItems = new ArrayList<>();
    private Map<Integer, Product> productMap = new HashMap<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pos);

        // Init DAOs
        productDao = new ProductDao(this);
        transactionDao = new TransactionDao(this);
        transactionDetailDao = new TransactionDetailDao(this);

        // Init Views
        tvTotalPrice = findViewById(R.id.text_view_total_price);
        Button btnCheckout = findViewById(R.id.button_checkout);

        setupProductRecyclerView();
        setupCartRecyclerView();

        loadProducts();

        btnCheckout.setOnClickListener(v -> checkout());
    }

    private void setupProductRecyclerView() {
        rvProducts = findViewById(R.id.recycler_view_pos_products);
        rvProducts.setLayoutManager(new LinearLayoutManager(this));
        productAdapter = new PosProductAdapter(productList, this::addToCart);
        rvProducts.setAdapter(productAdapter);
    }

    private void setupCartRecyclerView() {
        rvCart = findViewById(R.id.recycler_view_cart);
        rvCart.setLayoutManager(new LinearLayoutManager(this));
        cartAdapter = new CartAdapter(cartItems, productId -> productMap.get(productId).getName(), this::removeFromCart);
        rvCart.setAdapter(cartAdapter);
    }

    private void loadProducts() {
        productDao.open();
        productList.clear();
        productMap.clear();
        List<Product> allProducts = productDao.getAllProducts();
        productList.addAll(allProducts);
        for (Product p : allProducts) {
            productMap.put(p.getId(), p);
        }
        productDao.close();
        productAdapter.setProducts(productList);
    }

    private void addToCart(Product product) {
        if (product.getStock() <= 0) {
            Toast.makeText(this, "Stok produk habis", Toast.LENGTH_SHORT).show();
            return;
        }

        // Cek apakah produk sudah ada di keranjang
        for (TransactionDetail item : cartItems) {
            if (item.getProductId() == product.getId()) {
                item.setQuantity(item.getQuantity() + 1);
                updateCart();
                return;
            }
        }

        // Jika belum ada, tambahkan item baru
        TransactionDetail newItem = new TransactionDetail(0, 0, product.getId(), 1, product.getPrice());
        cartItems.add(newItem);
        updateCart();
    }

    private void removeFromCart(TransactionDetail item) {
        cartItems.remove(item);
        updateCart();
    }

    private void updateCart() {
        cartAdapter.updateCart(cartItems);
        calculateTotal();
    }

    private void calculateTotal() {
        int total = 0;
        for (TransactionDetail item : cartItems) {
            total += item.getPriceAtTransaction() * item.getQuantity();
        }
        tvTotalPrice.setText("Total: Rp " + total);
    }

    private void checkout() {
        if (cartItems.isEmpty()) {
            Toast.makeText(this, "Keranjang masih kosong", Toast.LENGTH_SHORT).show();
            return;
        }

        int totalAmount = 0;
        for (TransactionDetail item : cartItems) {
            totalAmount += item.getPriceAtTransaction() * item.getQuantity();
        }

        // Buka koneksi database
        transactionDao.open();
        transactionDetailDao.open();
        productDao.open();

        // 1. Simpan transaksi utama
        long transactionId = transactionDao.addTransaction(totalAmount);

        // 2. Simpan detail transaksi dan update stok
        for (TransactionDetail item : cartItems) {
            transactionDetailDao.addTransactionDetail(transactionId, item.getProductId(), item.getQuantity(), item.getPriceAtTransaction());

            Product product = productMap.get(item.getProductId());
            if (product != null) {
                int newStock = product.getStock() - item.getQuantity();
                product.setStock(newStock);
                productDao.updateProduct(product);
            }
        }

        // Tutup koneksi
        productDao.close();
        transactionDetailDao.close();
        transactionDao.close();

        Toast.makeText(this, "Transaksi berhasil!", Toast.LENGTH_LONG).show();

        // Reset tampilan
        cartItems.clear();
        updateCart();
        loadProducts(); // Reload produk untuk update stok di UI
    }
}
