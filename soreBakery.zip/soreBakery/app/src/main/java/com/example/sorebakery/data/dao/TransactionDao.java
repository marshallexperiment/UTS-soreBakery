package com.example.sorebakery.data.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.sorebakery.data.model.Transaction;
import com.example.sorebakery.database.DatabaseHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TransactionDao {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    private String[] allColumns = {
            DatabaseHelper.COLUMN_TRANSACTION_ID,
            DatabaseHelper.COLUMN_TRANSACTION_DATE,
            DatabaseHelper.COLUMN_TRANSACTION_TOTAL
    };

    public TransactionDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long addTransaction(int totalAmount) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TRANSACTION_DATE, getCurrentDateTime());
        values.put(DatabaseHelper.COLUMN_TRANSACTION_TOTAL, totalAmount);

        return database.insert(DatabaseHelper.TABLE_TRANSACTIONS, null, values);
    }

    public List<Transaction> getAllTransactions() {
        List<Transaction> transactions = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE_TRANSACTIONS, allColumns, null, null, null, null, DatabaseHelper.COLUMN_TRANSACTION_ID + " DESC");

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Transaction transaction = cursorToTransaction(cursor);
            transactions.add(transaction);
            cursor.moveToNext();
        }
        cursor.close();
        return transactions;
    }

    private Transaction cursorToTransaction(Cursor cursor) {
        Transaction transaction = new Transaction();
        transaction.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TRANSACTION_ID)));
        transaction.setTransactionDate(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TRANSACTION_DATE)));
        transaction.setTotalAmount(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TRANSACTION_TOTAL)));
        return transaction;
    }

    private String getCurrentDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }
}
