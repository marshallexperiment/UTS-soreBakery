package com.example.sorebakery.data.model;

public class Transaction {
    private int id;
    private String transactionDate;
    private int totalAmount;

    public Transaction() {
        // Konstruktor kosong
    }

    public Transaction(int id, String transactionDate, int totalAmount) {
        this.id = id;
        this.transactionDate = transactionDate;
        this.totalAmount = totalAmount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }
}
