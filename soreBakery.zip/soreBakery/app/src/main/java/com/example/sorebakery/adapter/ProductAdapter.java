package com.example.sorebakery.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.sorebakery.R;
import com.example.sorebakery.data.model.Product;

import java.io.File;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    private List<Product> productList;
    private OnItemClickListener clickListener;
    private OnItemLongClickListener longClickListener;

    public interface OnItemClickListener {
        void onItemClick(Product product);
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(Product product);
    }

    public ProductAdapter(List<Product> productList, OnItemClickListener clickListener, OnItemLongClickListener longClickListener) {
        this.productList = productList;
        this.clickListener = clickListener;
        this.longClickListener = longClickListener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row_product, parent, false);
        return new ProductViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product currentProduct = productList.get(position);
        holder.textViewName.setText(currentProduct.getName());
        holder.textViewPrice.setText("Rp " + currentProduct.getPrice());
        holder.textViewStock.setText("Stok: " + currentProduct.getStock());

        // --- MEMUAT GAMBAR DARI FILE INTERNAL ---
        if (currentProduct.getImagePath() != null && !currentProduct.getImagePath().isEmpty()) {
            Glide.with(holder.itemView.getContext())
                 .load(new File(currentProduct.getImagePath())) // Load dari File Path
                 .placeholder(R.drawable.ic_launcher_background)
                 .error(android.R.drawable.stat_notify_error)
                 .centerCrop()
                 .into(holder.imageViewProduct);
        } else {
            Glide.with(holder.itemView.getContext())
                 .load(R.drawable.ic_launcher_background) // Placeholder
                 .centerCrop()
                 .into(holder.imageViewProduct);
        }

        holder.itemView.setOnClickListener(v -> clickListener.onItemClick(currentProduct));
        holder.itemView.setOnLongClickListener(v -> {
            longClickListener.onItemLongClick(currentProduct);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public void setProducts(List<Product> products) {
        this.productList = products;
        notifyDataSetChanged();
    }

    static class ProductViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewName;
        private final TextView textViewPrice;
        private final TextView textViewStock;
        private final ImageView imageViewProduct;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.text_view_product_name);
            textViewPrice = itemView.findViewById(R.id.text_view_product_price);
            textViewStock = itemView.findViewById(R.id.text_view_product_stock);
            imageViewProduct = itemView.findViewById(R.id.image_view_product);
        }
    }
}
