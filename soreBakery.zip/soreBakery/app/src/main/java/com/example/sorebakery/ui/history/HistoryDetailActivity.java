package com.example.sorebakery.ui.history;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sorebakery.R;
import com.example.sorebakery.adapter.CartAdapter; // Kita bisa re-use CartAdapter dengan sedikit trik
import com.example.sorebakery.data.dao.ProductDao;
import com.example.sorebakery.data.dao.TransactionDao;
import com.example.sorebakery.data.dao.TransactionDetailDao;
import com.example.sorebakery.data.model.Product;
import com.example.sorebakery.data.model.Transaction;
import com.example.sorebakery.data.model.TransactionDetail;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HistoryDetailActivity extends AppCompatActivity {

    private TextView tvTransactionId, tvTransactionDate, tvTotalAmount;
    private RecyclerView rvTransactionItems;

    private TransactionDao transactionDao;
    private TransactionDetailDao transactionDetailDao;
    private ProductDao productDao;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_detail);

        tvTransactionId = findViewById(R.id.text_view_detail_transaction_id);
        tvTransactionDate = findViewById(R.id.text_view_detail_transaction_date);
        tvTotalAmount = findViewById(R.id.text_view_detail_total_amount);
        rvTransactionItems = findViewById(R.id.recycler_view_history_detail_items);
        rvTransactionItems.setLayoutManager(new LinearLayoutManager(this));

        transactionDao = new TransactionDao(this);
        transactionDetailDao = new TransactionDetailDao(this);
        productDao = new ProductDao(this);

        long transactionId = getIntent().getLongExtra("TRANSACTION_ID", -1);

        if (transactionId != -1) {
            loadTransactionDetails(transactionId);
        }
    }

    private void loadTransactionDetails(long transactionId) {
        transactionDao.open();
        transactionDetailDao.open();
        productDao.open();

        // 1. Get Transaction
        // Inefficient way, a getById would be better.
        Transaction transaction = null;
        for(Transaction t : transactionDao.getAllTransactions()){
            if(t.getId() == transactionId){
                transaction = t;
                break;
            }
        }

        // 2. Get Transaction Details
        List<TransactionDetail> details = transactionDetailDao.getTransactionDetails(transactionId);
        
        // 3. Create a map for product names
        Map<Integer, String> productNames = new HashMap<>();
        for (Product p : productDao.getAllProducts()) {
            productNames.put(p.getId(), p.getName());
        }

        productDao.close();
        transactionDetailDao.close();
        transactionDao.close();

        if (transaction != null) {
            tvTransactionId.setText("Transaksi #" + transaction.getId());
            tvTransactionDate.setText(transaction.getTransactionDate());
            tvTotalAmount.setText("Total: Rp " + transaction.getTotalAmount());
            
            // Untuk adapter, kita re-use CartAdapter tapi buat listener-nya tidak melakukan apa-apa.
            // Ini adalah cara cepat, idealnya buat adapter khusus.
            CartAdapter adapter = new CartAdapter(details, productNames::get, item -> {});
            rvTransactionItems.setAdapter(adapter);
        }
    }
}
