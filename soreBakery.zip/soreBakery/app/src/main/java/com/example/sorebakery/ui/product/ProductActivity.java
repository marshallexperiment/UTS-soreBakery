package com.example.sorebakery.ui.product;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sorebakery.R;
import com.example.sorebakery.adapter.ProductAdapter;
import com.example.sorebakery.data.dao.ProductDao;
import com.example.sorebakery.data.model.Product;
import com.example.sorebakery.util.ImageUtil;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class ProductActivity extends AppCompatActivity {

    private ProductDao productDao;
    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private List<Product> productList = new ArrayList<>();

    public static final int REQUEST_CODE_ADD_EDIT = 1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        productDao = new ProductDao(this);

        recyclerView = findViewById(R.id.recycler_view_products);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ProductAdapter(productList,
                product -> { // OnItemClickListener for editing
                    Intent intent = new Intent(ProductActivity.this, AddEditProductActivity.class);
                    intent.putExtra("PRODUCT_ID", (long) product.getId());
                    startActivityForResult(intent, REQUEST_CODE_ADD_EDIT);
                },
                this::showDeleteConfirmationDialog // OnItemLongClickListener for deleting
        );
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fab_add_product);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(ProductActivity.this, AddEditProductActivity.class);
            startActivityForResult(intent, REQUEST_CODE_ADD_EDIT);
        });
    }

    private void showDeleteConfirmationDialog(Product product) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus Produk")
                .setMessage("Apakah Anda yakin ingin menghapus produk '" + product.getName() + "'?")
                .setPositiveButton("Hapus", (dialog, which) -> deleteProduct(product))
                .setNegativeButton("Batal", null)
                .show();
    }

    private void deleteProduct(Product product) {
        // Hapus file gambar dari internal storage
        ImageUtil.deleteImageFromInternalStorage(product.getImagePath());

        // Hapus produk dari database
        productDao.open();
        productDao.deleteProduct(product);
        productDao.close();

        Toast.makeText(this, "Produk '" + product.getName() + "' telah dihapus.", Toast.LENGTH_SHORT).show();

        loadProducts(); // Refresh the list
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProducts();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD_EDIT && resultCode == RESULT_OK) {
            // onResume() is already called, which reloads the products. No action needed.
        }
    }

    private void loadProducts() {
        productDao.open();
        productList.clear();
        productList.addAll(productDao.getAllProducts());
        adapter.setProducts(productList);
        productDao.close();
    }
}
