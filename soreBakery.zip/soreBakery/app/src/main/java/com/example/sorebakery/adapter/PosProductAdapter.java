package com.example.sorebakery.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.sorebakery.R;
import com.example.sorebakery.data.model.Product;

import java.io.File;
import java.util.List;

public class PosProductAdapter extends RecyclerView.Adapter<PosProductAdapter.PosProductViewHolder> {

    private List<Product> productList;
    private OnProductClickListener listener;

    public interface OnProductClickListener {
        void onProductClick(Product product);
    }

    public PosProductAdapter(List<Product> productList, OnProductClickListener listener) {
        this.productList = productList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public PosProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row_product, parent, false);
        return new PosProductViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull PosProductViewHolder holder, int position) {
        Product currentProduct = productList.get(position);
        holder.textViewName.setText(currentProduct.getName());
        holder.textViewPrice.setText("Rp " + currentProduct.getPrice());

        // --- MEMUAT GAMBAR DARI FILE INTERNAL ---
        if (currentProduct.getImagePath() != null && !currentProduct.getImagePath().isEmpty()) {
            Glide.with(holder.itemView.getContext())
                 .load(new File(currentProduct.getImagePath())) // Load dari File Path
                 .placeholder(R.drawable.ic_launcher_background)
                 .error(android.R.drawable.stat_notify_error)
                 .centerCrop()
                 .into(holder.imageViewProduct);
        } else {
            Glide.with(holder.itemView.getContext())
                 .load(R.drawable.ic_launcher_background) // Placeholder
                 .centerCrop()
                 .into(holder.imageViewProduct);
        }

        holder.itemView.setOnClickListener(v -> listener.onProductClick(currentProduct));
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public void setProducts(List<Product> products) {
        this.productList = products;
        notifyDataSetChanged();
    }

    static class PosProductViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewName;
        private final TextView textViewPrice;
        private final ImageView imageViewProduct;

        public PosProductViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.text_view_product_name);
            textViewPrice = itemView.findViewById(R.id.text_view_product_price);
            imageViewProduct = itemView.findViewById(R.id.image_view_product);
        }
    }
}
