package com.example.sorebakery.data.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.sorebakery.data.model.TransactionDetail;
import com.example.sorebakery.database.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class TransactionDetailDao {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    private String[] allColumns = {
            DatabaseHelper.COLUMN_ITEM_ID,
            DatabaseHelper.COLUMN_ITEM_TRANSACTION_ID,
            DatabaseHelper.COLUMN_ITEM_PRODUCT_ID,
            DatabaseHelper.COLUMN_ITEM_QUANTITY,
            DatabaseHelper.COLUMN_ITEM_PRICE_AT_TRANSACTION
    };

    public TransactionDetailDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void addTransactionDetail(long transactionId, int productId, int quantity, int priceAtTransaction) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_TRANSACTION_ID, transactionId);
        values.put(DatabaseHelper.COLUMN_ITEM_PRODUCT_ID, productId);
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, quantity);
        values.put(DatabaseHelper.COLUMN_ITEM_PRICE_AT_TRANSACTION, priceAtTransaction);

        database.insert(DatabaseHelper.TABLE_TRANSACTION_ITEMS, null, values);
    }

    public List<TransactionDetail> getTransactionDetails(long transactionId) {
        List<TransactionDetail> details = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE_TRANSACTION_ITEMS, allColumns, DatabaseHelper.COLUMN_ITEM_TRANSACTION_ID + " = " + transactionId, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            TransactionDetail detail = cursorToTransactionDetail(cursor);
            details.add(detail);
            cursor.moveToNext();
        }
        cursor.close();
        return details;
    }

    private TransactionDetail cursorToTransactionDetail(Cursor cursor) {
        TransactionDetail detail = new TransactionDetail();
        detail.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_ID)));
        detail.setTransactionId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_TRANSACTION_ID)));
        detail.setProductId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_PRODUCT_ID)));
        detail.setQuantity(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_QUANTITY)));
        detail.setPriceAtTransaction(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_PRICE_AT_TRANSACTION)));
        return detail;
    }
}
