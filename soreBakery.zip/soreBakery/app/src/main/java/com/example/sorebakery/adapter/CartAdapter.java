package com.example.sorebakery.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sorebakery.R;
import com.example.sorebakery.data.model.TransactionDetail;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private List<TransactionDetail> cartItems;
    private OnItemAction listener;

    public interface ProductNameProvider {
        String getProductName(int productId);
    }

    private ProductNameProvider nameProvider;

    public interface OnItemAction {
        void onRemoveItem(TransactionDetail item);
    }

    public CartAdapter(List<TransactionDetail> cartItems, ProductNameProvider nameProvider, OnItemAction listener) {
        this.cartItems = cartItems;
        this.nameProvider = nameProvider;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row_cart, parent, false);
        return new CartViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        TransactionDetail currentItem = cartItems.get(position);
        
        String productName = nameProvider.getProductName(currentItem.getProductId());
        holder.textViewName.setText(productName);
        holder.textViewQuantity.setText("x " + currentItem.getQuantity());
        holder.textViewSubtotal.setText("Rp " + (currentItem.getQuantity() * currentItem.getPriceAtTransaction()));

        holder.buttonRemove.setOnClickListener(v -> listener.onRemoveItem(currentItem));
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    public void updateCart(List<TransactionDetail> newCartItems) {
        this.cartItems = newCartItems;
        notifyDataSetChanged();
    }

    static class CartViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewName;
        private final TextView textViewQuantity;
        private final TextView textViewSubtotal;
        private final ImageButton buttonRemove; // Tipe diubah ke ImageButton

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.text_view_cart_item_name);
            textViewQuantity = itemView.findViewById(R.id.text_view_cart_item_quantity);
            textViewSubtotal = itemView.findViewById(R.id.text_view_cart_item_subtotal);
            buttonRemove = itemView.findViewById(R.id.button_remove_cart_item);
        }
    }
}
