package com.example.sorebakery.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sorebakery.R;
import com.example.sorebakery.data.model.Transaction;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder> {

    private List<Transaction> transactionList;
    private OnHistoryItemClickListener listener;

    public interface OnHistoryItemClickListener {
        void onItemClick(Transaction transaction);
    }

    public HistoryAdapter(List<Transaction> transactionList, OnHistoryItemClickListener listener) {
        this.transactionList = transactionList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row_history, parent, false);
        return new HistoryViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, int position) {
        Transaction currentTransaction = transactionList.get(position);
        holder.textViewTransactionId.setText("Transaksi #" + currentTransaction.getId());
        holder.textViewTransactionDate.setText(currentTransaction.getTransactionDate());
        holder.textViewTotalAmount.setText("Total: Rp " + currentTransaction.getTotalAmount());
        holder.itemView.setOnClickListener(v -> listener.onItemClick(currentTransaction));
    }

    @Override
    public int getItemCount() {
        return transactionList.size();
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactionList = transactions;
        notifyDataSetChanged();
    }

    static class HistoryViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewTransactionId;
        private final TextView textViewTransactionDate;
        private final TextView textViewTotalAmount;

        public HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTransactionId = itemView.findViewById(R.id.text_view_history_id);
            textViewTransactionDate = itemView.findViewById(R.id.text_view_history_date);
            textViewTotalAmount = itemView.findViewById(R.id.text_view_history_total);
        }
    }
}
