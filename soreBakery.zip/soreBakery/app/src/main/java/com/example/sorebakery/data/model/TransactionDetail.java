package com.example.sorebakery.data.model;

public class TransactionDetail {
    private int id;
    private int transactionId;
    private int productId;
    private int quantity;
    private int priceAtTransaction;

    public TransactionDetail() {
        // Konstruktor kosong
    }

    public TransactionDetail(int id, int transactionId, int productId, int quantity, int priceAtTransaction) {
        this.id = id;
        this.transactionId = transactionId;
        this.productId = productId;
        this.quantity = quantity;
        this.priceAtTransaction = priceAtTransaction;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getPriceAtTransaction() {
        return priceAtTransaction;
    }

    public void setPriceAtTransaction(int priceAtTransaction) {
        this.priceAtTransaction = priceAtTransaction;
    }
}
